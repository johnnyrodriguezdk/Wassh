<?php
/**
 * =======================================================================================
 * @author DTunnelMod Team
 * @name API Mestra de Sincronização (Update) - Multi-Usuário Premium
 * @description Distribui os JSONs dinâmicos (Config, CDN, Layout, Textos, Categorias).
 * @version 5.0.0 - Fully Integrated with Trem Bala & DTunnel
 * =======================================================================================
 */

// Headers de segurança e configuração para JSON (Anti-Cache Pesado)
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Recebe os parâmetros do App
$type = $_GET['type'] ?? '';
$uuid = $_GET['uuid'] ?? ($_GET['user'] ?? ''); // Aceita 'uuid' ou 'user' para máxima compatibilidade

// Se faltar parâmetro, retorna array vazia para não crachar o App
if (empty($type) || empty($uuid)) {
    echo json_encode([]);
    exit;
}

$dbDir = __DIR__ . '/../db';
$usuariosFile = $dbDir . '/usuarios.json';

// Valida se o banco principal existe
if (!file_exists($usuariosFile)) {
    echo json_encode([]);
    exit;
}

$usuarios = json_decode(file_get_contents($usuariosFile), true) ?: [];
$userEmail = '';
$userStatus = '';

// Busca o usuário pelo UUID ou pelo Hash MD5 do email
foreach ($usuarios as $u) {
    if ((isset($u['uuid']) && strtolower($u['uuid']) === strtolower($uuid)) || md5($u['email']) === $uuid) {
        $userEmail = $u['email'];
        $userStatus = $u['status'] ?? 'active';
        break;
    }
}

// Se não achar o usuário ou se a conta estiver suspensa, barra o envio (Manda array vazio)
if (empty($userEmail) || $userStatus !== 'active') {
    echo json_encode([]);
    exit;
}

/**
 * Função Auxiliar para Limpar Dados Internos
 * Remove o 'user_email' de dentro da Array para o JSON do App ficar limpo, enxuto e seguro.
 */
function cleanData($dataArray) {
    $cleaned = [];
    foreach ($dataArray as $item) {
        if (isset($item['user_email'])) {
            unset($item['user_email']);
        }
        $cleaned[] = $item; // Garante que o Array seja sempre [0, 1, 2...] sem falhas no índice
    }
    return $cleaned;
}

// ============================================================================
// ROTEADOR DA API: ENTREGA EXATAMENTE O QUE O APP PEDIR
// ============================================================================
switch ($type) {
    
    // 1. ENTREGA DE CONFIGURAÇÕES (SERVIDORES/PAYLOADS)
    case 'config':
    case 'app_config':
        $dbFile = $dbDir . '/configs.json';
        $data = file_exists($dbFile) ? json_decode(file_get_contents($dbFile), true) : [];
        
        $filtered = array_filter($data, function($item) use ($userEmail) {
            return isset($item['user_email']) && $item['user_email'] === $userEmail && ($item['status'] ?? 'ACTIVE') === 'ACTIVE';
        });
        
        // Ordena exatamente pela ordem (Sorter) que você configurou no painel
        usort($filtered, function($a, $b) {
            return ((int)($a['sorter'] ?? 1)) - ((int)($b['sorter'] ?? 1));
        });
        
        echo json_encode(cleanData($filtered), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        break;

    // 2. ENTREGA DE CATEGORIAS
    case 'category':
        $dbFile = $dbDir . '/categories.json';
        $data = file_exists($dbFile) ? json_decode(file_get_contents($dbFile), true) : [];
        
        $filtered = array_filter($data, function($item) use ($userEmail) {
            return isset($item['user_email']) && $item['user_email'] === $userEmail && ($item['status'] ?? 'ACTIVE') === 'ACTIVE';
        });
        
        usort($filtered, function($a, $b) {
            return ((int)($a['sorter'] ?? 1)) - ((int)($b['sorter'] ?? 1));
        });
        
        echo json_encode(cleanData($filtered), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        break;

    // 3. ENTREGA DE CDN
    case 'cdn':
        $dbFile = $dbDir . '/cdn.json';
        $data = file_exists($dbFile) ? json_decode(file_get_contents($dbFile), true) : [];
        
        $filtered = array_filter($data, function($item) use ($userEmail) {
            return isset($item['user_email']) && $item['user_email'] === $userEmail;
        });
        
        echo json_encode(cleanData($filtered), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        break;

    // 4. ENTREGA DE LAYOUT (CORES, LOGO, BOTOES E MOCKUPS)
    case 'layout':
    case 'app_layout':
        $dbFile = $dbDir . '/app_layouts.json';
        $data = file_exists($dbFile) ? json_decode(file_get_contents($dbFile), true) : [];
        
        $filtered = array_filter($data, function($item) use ($userEmail) {
            return isset($item['user_email']) && $item['user_email'] === $userEmail;
        });
        
        $activeLayoutData = [];
        // Pega somente o Layout que está "ATIVO" no painel
        foreach ($filtered as $layout) {
            if (!empty($layout['is_active'])) {
                $activeLayoutData = $layout['layout_data'] ?? [];
                break;
            }
        }
        
        // Se der algum bug e nenhum estiver ativo, puxa o primeiro da lista
        if (empty($activeLayoutData) && !empty($filtered)) {
            $first = reset($filtered);
            $activeLayoutData = $first['layout_data'] ?? [];
        }
        
        echo json_encode($activeLayoutData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        break;

    // 5. ENTREGA DE TEXTOS (DICIONÁRIO DO APP)
    case 'text':
    case 'app_text':
        $dbFile = $dbDir . '/textos.json';
        $data = file_exists($dbFile) ? json_decode(file_get_contents($dbFile), true) : [];
        
        // Puxa exatamente a array de textos daquele email
        $userTexts = $data[$userEmail] ?? [];
        
        echo json_encode($userTexts, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        break;

    // 6. ENTREGA DA VERSÃO (SISTEMA DE GATILHO QUE FIZEMOS)
    case 'version':
        $dbFile = $dbDir . '/version.json';
        $data = file_exists($dbFile) ? json_decode(file_get_contents($dbFile), true) : ['version' => 100];
        
        // Retorna a versão para forçar o update no app
        echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        break;

    // FALLBACK DE SEGURANÇA
    default:
        echo json_encode([]);
        break;
}