<?php
/**
 * =======================================================================================
 * @author DTunnelMod Team
 * @name Gerador de APK Dinâmico (Trem Bala V5) - UI Premium Original
 * @description Injeção de credenciais, Logs reais idênticos, Integração i18n global.
 * =======================================================================================
 */

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

if (!defined('DTUNNEL_APP')) { header('Location: /404'); exit; }
if (session_status() === PHP_SESSION_NONE) { session_start(); }

$sessionEmail = $_SESSION['email'] ?? '';
if (empty($sessionEmail)) { header('Location: /login'); exit; }

// Diretórios necessários
$dirBase = __DIR__ . '/../apk_base';
$dirDown = __DIR__ . '/../downloads';
$dbUsuarios = __DIR__ . '/../db/usuarios.json';

// Cria as pastas se não existirem
foreach ([$dirBase, $dirDown] as $dir) {
    if (!is_dir($dir)) { mkdir($dir, 0755, true); }
}

// ======================================================================
// SISTEMA DE SEGURANÇA: LIMPEZA DE APKS ANTIGOS (EXPIRAÇÃO DE 2 MINUTOS)
// ======================================================================
$files = glob($dirDown . '/*.apk');
$now = time();
foreach ($files as $file) {
    if (is_file($file)) {
        if ($now - filemtime($file) >= 120) { // 120 segundos = 2 minutos
            @unlink($file);
        }
    }
}

// Carrega o UUID do usuário logado para montar a credencial
$userUuid = '---';
if (file_exists($dbUsuarios)) {
    $usuarios = json_decode(file_get_contents($dbUsuarios), true) ?: [];
    foreach ($usuarios as $u) {
        if (strtolower($u['email']) === strtolower($sessionEmail)) {
            $userUuid = $u['uuid'] ?? md5($sessionEmail);
            break;
        }
    }
}

// ----------------------------------------------------------------------
// PROCESSAMENTO AJAX (BACKEND DE GERAÇÃO)
// ----------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $_GET['action'] ?? ($input['action'] ?? '');

    // 1. LISTAR BASES DISPONÍVEIS NA PASTA apk_base
    if ($action === 'list_bases') {
        $bases = [];
        $files = glob($dirBase . '/*.apk');
        foreach ($files as $file) {
            $bases[] = basename($file);
        }
        echo json_encode(['success' => true, 'bases' => $bases]);
        exit;
    }

    // 2. EXCLUIR APK GERADO
    if ($action === 'delete_apk') {
        $filename = $input['filename'] ?? '';
        $filepath = $dirDown . '/' . basename($filename);
        if (file_exists($filepath) && strpos($filepath, '.apk') !== false) {
            @unlink($filepath);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Arquivo não encontrado ou já expirado.']);
        }
        exit;
    }

    // 3. O CORAÇÃO: GERAR APK E INJETAR JSON
    if ($action === 'build_apk') {
        $baseFile = $input['base'] ?? '';
        $appName = preg_replace('/[^a-zA-Z0-9]/', '', $input['name'] ?? 'DTunnelApp');
        
        if (empty($baseFile)) {
            echo json_encode(['success' => false, 'error' => 'Nenhuma base selecionada.']); exit;
        }

        $sourcePath = $dirBase . '/' . basename($baseFile);
        if (!file_exists($sourcePath)) {
            echo json_encode(['success' => false, 'error' => 'Arquivo base não encontrado no servidor.']); exit;
        }

        // Nome do arquivo gerado (Único estilo painel: uuid/versao_base.apk)
        $uniqueId = substr(md5(uniqid()), 0, 10);
        $finalFilename = $uniqueId . '_' . ($input['versionName'] ?? '1.0') . '_' . $appName . '.apk';
        $destinationPath = $dirDown . '/' . $finalFilename;

        // Copia a base para a pasta de downloads
        if (!copy($sourcePath, $destinationPath)) {
            echo json_encode(['success' => false, 'error' => 'Falha ao copiar arquivo base.']); exit;
        }

        // Monta o JSON da Credencial
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
        $domain = $_SERVER['HTTP_HOST'];
        $apiEndpoint = "{$protocol}://{$domain}/api/update.php";
        
        $credJson = [
            "cdn" => "{$apiEndpoint}?type=cdn&uuid={$userUuid}",
            "category" => "{$apiEndpoint}?type=category&uuid={$userUuid}",
            "app_config" => "{$apiEndpoint}?type=config&uuid={$userUuid}",
            "app_layout" => "{$apiEndpoint}?type=layout&uuid={$userUuid}",
            "app_text" => "{$apiEndpoint}?type=text&uuid={$userUuid}",
            "credits" => "@LightXVD and @Kiritosan",
            "channel" => "@dtunnelmod",
            "group" => "@dtunnelmodgroup"
        ];
        $jsonString = json_encode($credJson, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

        // ABRE O APK COMO ZIP E INJETA O JSON NA PASTA ASSETS
        $zip = new ZipArchive;
        if ($zip->open($destinationPath) === TRUE) {
            $zip->addFromString('assets/dtunnelmod.json', $jsonString);
            $zip->close();
            
            // Simula o path gerado igual da imagem
            $downloadUrl = "{$protocol}://{$domain}/build/{$uniqueId}/" . ($input['versionName'] ?? '1.0') . "_{$appName}.apk";
            
            echo json_encode([
                'success' => true, 
                'download_url' => $downloadUrl,
                'real_url' => "{$protocol}://{$domain}/downloads/{$finalFilename}",
                'filename' => $finalFilename,
                'uuid' => $uniqueId,
                'date' => date('d/m/Y, H:i')
            ]);
        } else {
            @unlink($destinationPath);
            echo json_encode(['success' => false, 'error' => 'Falha ao abrir e modificar o APK.']);
        }
        exit;
    }

    echo json_encode(['success' => false, 'error' => 'Ação desconhecida']); exit;
}

$pageTitle = 'Gerar APK';
ob_start();
?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
/* ==========================================================================
   ESTILOS PREMIUM - GERADOR DE APK (IDÊNTICO AO ORIGINAL)
   ========================================================================== */
.apk-wrapper {
    --card-bg: #ffffff; --card-border: #e2e8f0; --text-main: #0f172a; --text-muted: #64748b; --text-subtle: #94a3b8;
    --inner-bg: #f8fafc; --primary: #10b981; --primary-light: #d1fae5; --accent: #3b82f6; --success: #10b981; --danger: #ef4444; 
    --log-bg: #0f172a; --log-text: #cbd5e1; --log-card-border: #1e293b;
    padding: 16px; max-width: 900px; margin: 0 auto; font-family: 'Manrope', system-ui, sans-serif;
    display: flex; flex-direction: column; gap: 24px;
}

:root.dark .apk-wrapper, body.dark .apk-wrapper {
    --card-bg: #1e1e24; --card-border: #2d2d35; --text-main: #f8fafc; --text-muted: #94a3b8; --text-subtle: #64748b;
    --inner-bg: #18181b; --log-bg: #0b0f19; --log-text: #cbd5e1; --log-card-border: #1e293b;
    --primary: #10b981; --primary-light: rgba(16, 185, 129, 0.1);
}

.apk-wrapper * { outline: none; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }

h1.main-title { font-size: 1.8rem; font-weight: 800; color: var(--text-main); margin: 0; }

/* CARTÕES PADRÃO */
.apk-card { background: var(--card-bg); border: 1px solid var(--card-border); border-radius: 24px; padding: 24px; display: flex; flex-direction: column; gap: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.015);}
.card-header-title { font-size: 1.25rem; font-weight: 800; color: var(--text-main); margin: 0; display: flex; align-items: center; gap: 10px; }
.card-desc { font-size: 0.9rem; font-weight: 500; color: var(--text-muted); margin: -10px 0 0 0; line-height: 1.5; }

/* BLOCO TOP: Resumo da Build */
.build-summary-box { display: flex; align-items: center; gap: 16px; background: transparent; border: 1px solid var(--card-border); border-radius: 20px; padding: 16px 20px; }
.bsb-icon { width: 46px; height: 46px; border-radius: 14px; background: var(--inner-bg); border: 1px solid var(--card-border); display: flex; align-items: center; justify-content: center; color: var(--text-muted); flex-shrink: 0; }
.bsb-icon svg { width: 22px; stroke-width: 2.2px; }
.bsb-info { display: flex; flex-direction: column; flex: 1; }
.bsb-lbl { font-size: 0.72rem; font-weight: 800; color: var(--text-subtle); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px;}
.bsb-val { font-size: 1.05rem; font-weight: 800; color: var(--text-main); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 250px;}

.summary-grid { display: grid; grid-template-columns: 1fr; gap: 12px; }

/* CAIXA DE LINKS DA SESSÃO */
.session-links-header { display: flex; gap: 10px; margin-bottom: 5px; overflow-x: auto; padding-bottom: 5px; scrollbar-width: none;}
.session-links-header::-webkit-scrollbar { display: none; }
.sl-tab { padding: 8px 20px; border-radius: 50px; font-size: 0.85rem; font-weight: 800; border: 1px solid var(--card-border); background: transparent; color: var(--text-muted); cursor: pointer; transition: 0.2s; white-space: nowrap;}
.sl-tab.active { background: var(--inner-bg); color: var(--text-main); border-color: var(--card-border); }
.empty-links { border: 1px dashed var(--card-border); border-radius: 20px; padding: 40px 20px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; background: var(--inner-bg); }
.empty-links svg { width: 32px; color: var(--text-muted); margin-bottom: 12px; }
.empty-links span { font-size: 1rem; font-weight: 800; color: var(--text-main); }
.empty-links p { font-size: 0.85rem; color: var(--text-subtle); margin: 4px 0 0 0; }

/* FORMULÁRIO DE COMPILAÇÃO */
.form-grid { display: grid; grid-template-columns: 1fr; gap: 16px; }
.form-group { display: flex; flex-direction: column; gap: 8px; }
.form-label { font-size: 0.85rem; font-weight: 800; color: var(--text-main); }
.form-input, .form-select { width: 100%; background: var(--inner-bg); border: 1px solid var(--card-border); border-radius: 16px; padding: 16px 18px; font-size: 0.95rem; font-weight: 600; color: var(--text-main); outline: none; transition: border 0.2s; appearance: none; }
.form-select { background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236b7280' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 16px center; background-size: 18px; padding-right: 40px; cursor: pointer; }
.form-input:focus, .form-select:focus { border-color: var(--text-muted); }

/* PACOTE OFFLINE */
.offline-grid { display: flex; flex-direction: column; gap: 12px; }
.checkbox-item { background: var(--inner-bg); border: 1px solid var(--card-border); border-radius: 16px; padding: 16px 18px; display: flex; align-items: center; gap: 14px; cursor: pointer; transition: 0.2s; }
.checkbox-item:active { transform: scale(0.98); }
.custom-cb { width: 24px; height: 24px; border-radius: 8px; border: 2px solid var(--card-border); background: transparent; display: flex; align-items: center; justify-content: center; transition: 0.2s; }
.checkbox-item input:checked + .custom-cb { background: var(--accent); border-color: var(--accent); }
.custom-cb svg { width: 14px; color: white; opacity: 0; transform: scale(0.5); transition: 0.2s; stroke-width: 3.5px; }
.checkbox-item input:checked + .custom-cb svg { opacity: 1; transform: scale(1); }
.cb-label { font-size: 0.95rem; font-weight: 800; color: var(--text-main); }

.btn-master-build { width: 100%; background: var(--inner-bg); border: 1px solid var(--card-border); color: var(--text-main); padding: 18px; border-radius: 18px; font-size: 1rem; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 10px; cursor: pointer; transition: 0.2s; margin-top: 10px; }
.btn-master-build:active { transform: scale(0.96); background: var(--card-border); }
.btn-master-build svg { width: 20px; stroke-width: 2.2px; }

/* ==========================================================================
   TELA DE COMPILAÇÃO EM ANDAMENTO (Terminal Premium Corrigido)
   ========================================================================== */
#build-progress-screen { display: none; flex-direction: column; gap: 20px; animation: fadeIn 0.4s ease-out; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

.prog-status-row { display: flex; align-items: center; gap: 16px; background: transparent; border: 1px solid var(--card-border); border-radius: 20px; padding: 16px 20px; }
.prog-icon-pulse { width: 46px; height: 46px; border-radius: 50%; background: transparent; border: 1px solid var(--card-border); color: var(--text-main); display: flex; align-items: center; justify-content: center; }
.prog-icon-pulse svg { width: 22px; color: var(--text-muted); stroke-width: 2.2px; }

.prog-bar-container { display: flex; flex-direction: column; gap: 10px; margin-top: 8px; }
.prog-bar-header { display: flex; justify-content: space-between; align-items: center; font-size: 0.95rem; font-weight: 800; color: var(--text-main); }
.prog-bar-bg { width: 100%; height: 8px; background: var(--inner-bg); border-radius: 10px; overflow: hidden; position: relative;}
.prog-bar-fill { height: 100%; width: 0%; background: linear-gradient(90deg, #0ea5e9, #10b981); border-radius: 10px; transition: width 0.3s ease-out; position: relative;}

/* TERMINAL DE LOGS PERFEITO DA IMAGEM */
.terminal-card { background: var(--log-bg); border-radius: 24px; overflow: hidden; border: 1px solid var(--log-card-border); display: flex; flex-direction: column; margin-top: 10px;}
.terminal-header { background: transparent; border-bottom: 1px solid rgba(255,255,255,0.05); padding: 20px 20px 16px 20px; display: flex; justify-content: space-between; align-items: flex-start; }
.th-title-wrap { display: flex; gap: 12px; align-items: flex-start; }
.th-title { font-size: 0.95rem; font-weight: 800; color: #fff; line-height: 1.3; }
.th-subtitle { font-size: 0.75rem; color: var(--text-subtle); font-weight: 500; }
.th-icon { color: #f8fafc; margin-top: 2px; }
.th-live { background: rgba(59, 130, 246, 0.15); color: #60a5fa; padding: 4px 12px; border-radius: 8px; font-size: 0.7rem; font-weight: 900; letter-spacing: 1px; border: 1px solid rgba(59, 130, 246, 0.3); animation: blink 1.5s infinite;}
@keyframes blink { 50% { opacity: 0.6; } }

.terminal-body { padding: 16px; height: 350px; overflow-y: auto; display: flex; flex-direction: column; gap: 14px; font-family: 'Space Grotesk', monospace; scrollbar-width: thin; scrollbar-color: #334155 transparent;}
.terminal-body::-webkit-scrollbar { width: 6px; }
.terminal-body::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }

/* Estrutura do Log IDÊNTICA ao print enviado */
.log-entry { display: flex; align-items: flex-start; gap: 14px; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.04); border-radius: 16px; padding: 16px; animation: slideUpLog 0.2s ease-out; }
.log-icon-left { width: 34px; height: 34px; border-radius: 10px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); display: flex; align-items: center; justify-content: center; color: #64748b; flex-shrink: 0; }
.log-icon-left svg { width: 16px; stroke-width: 2.2px; }
.log-content { display: flex; flex-direction: column; gap: 8px; flex: 1; }
.log-top-row { display: flex; align-items: center; gap: 10px; }
.log-num { font-size: 0.8rem; font-weight: 800; color: #94a3b8; letter-spacing: 0.5px;}
.log-badge-label { background: rgba(59, 130, 246, 0.15); color: #60a5fa; padding: 2px 8px; border-radius: 6px; font-size: 0.65rem; font-weight: 800; letter-spacing: 0.5px; border: 1px solid rgba(59, 130, 246, 0.3); }
.log-text { font-size: 0.85rem; color: var(--log-text); line-height: 1.5; word-break: break-all; }

/* ==========================================================================
   TELA DE SUCESSO E HISTÓRICO 
   ========================================================================== */
#build-success-screen { display: none; flex-direction: column; gap: 24px; animation: fadeIn 0.4s ease-out; }

/* Item do Histórico */
.history-item { background: transparent; border: 1px solid var(--card-border); border-radius: 20px; padding: 16px; display: flex; flex-direction: column; gap: 14px; margin-bottom: 12px; }
.hi-top { display: flex; align-items: center; gap: 12px; }
.hi-icon { width: 46px; height: 46px; border-radius: 14px; background: var(--inner-bg); border: 1px solid var(--card-border); display: flex; align-items: center; justify-content: center; color: var(--text-muted); flex-shrink: 0; }
.hi-info { display: flex; flex-direction: column; }
.hi-title { font-size: 1.05rem; font-weight: 800; color: var(--text-main); }
.hi-sub { font-size: 0.75rem; font-weight: 700; color: var(--text-subtle); text-transform: uppercase; margin-top: 2px; line-height: 1.4;}

/* Rolagem perfeita para o link sem cortar */
.hi-link-wrapper { background: var(--inner-bg); border: 1px solid var(--card-border); border-radius: 14px; padding: 12px 14px; width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; scrollbar-width: none;}
.hi-link-wrapper::-webkit-scrollbar { display: none; }
.hi-link-text { font-family: monospace; font-size: 0.85rem; color: var(--text-main); white-space: nowrap; font-weight: 600;}

/* Botões do histórico adaptáveis para mobile */
.hi-actions { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; width: 100%;}
.btn-hi { background: transparent; border: 1px solid var(--card-border); border-radius: 14px; padding: 12px 0; display: flex; justify-content: center; align-items: center; color: var(--text-main); cursor: pointer; transition: 0.2s; width: 100%;}
.btn-hi:active { transform: scale(0.95); background: var(--inner-bg); }
.btn-hi.trash { color: var(--danger); border-color: rgba(239, 68, 68, 0.2); }
.btn-hi svg { width: 20px; stroke-width: 2.2px; }

.btn-clear-history { width: 100%; background: transparent; border: 1px solid var(--card-border); color: var(--text-muted); padding: 14px; border-radius: 16px; font-size: 0.9rem; font-weight: 800; display: flex; align-items: center; justify-content: center; cursor: pointer; margin-bottom: 16px; }

/* Card APK Pronto (Verde) */
.apk-pronto-card { background: var(--card-bg); border: 1px solid var(--card-border); border-radius: 24px; padding: 24px; display: flex; flex-direction: column; gap: 16px; position: relative; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.015);}
.apk-pronto-card::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 4px; background: var(--primary); }

.ap-header { font-size: 1.3rem; font-weight: 800; color: var(--text-main); margin: 0; }
.ap-desc { font-size: 0.9rem; color: var(--text-muted); font-weight: 500; margin: -10px 0 6px 0;}

.ap-status-box { background: transparent; border: 1px solid var(--card-border); border-radius: 16px; padding: 16px; display: flex; align-items: center; gap: 14px; }
.ap-status-icon { width: 40px; height: 40px; border-radius: 50%; border: 1px solid var(--card-border); display: flex; align-items: center; justify-content: center; color: var(--text-muted); }
.ap-status-icon svg { width: 18px; stroke-width: 2.5px; }
.ap-status-icon.check { color: var(--primary); border-color: var(--primary-light); background: var(--primary-light); }

.final-link-container { border: 1px solid var(--primary); border-radius: 16px; padding: 16px; display: flex; flex-direction: column; gap: 8px; background: var(--primary-light); margin-top: 10px; width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; scrollbar-width: none;}
.final-link-container::-webkit-scrollbar { display: none; }
.flc-label { font-size: 0.7rem; font-weight: 800; color: var(--primary); text-transform: uppercase; letter-spacing: 0.5px; }
.flc-input { font-family: monospace; font-size: 0.85rem; color: var(--text-main); white-space: nowrap; font-weight: 600; }

.ap-buttons { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 10px; width: 100%;}
.btn-ap { background: transparent; border: 1px solid var(--card-border); border-radius: 14px; padding: 14px 0; font-weight: 800; font-size: 0.8rem; color: var(--text-main); display: flex; align-items: center; justify-content: center; gap: 6px; cursor: pointer; transition: 0.2s; white-space: nowrap;}
.btn-ap:active { transform: scale(0.95); background: var(--inner-bg); }
.btn-ap svg { width: 18px; stroke-width: 2.2px; }

@media (max-width: 480px) {
    .ap-buttons, .hi-actions { display: flex; flex-direction: column; }
    .btn-ap, .btn-hi { width: 100%; padding: 14px; }
}

/* TOASTS GLOBAIS */
#toast-container { position: fixed; top: 20px; right: 20px; z-index: 1000000; display: flex; flex-direction: column; gap: 10px; pointer-events: none; }
.toast { background: var(--card-bg); border: 1px solid var(--card-border); border-radius: 16px; padding: 16px 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); display: flex; align-items: center; gap: 12px; width: auto; min-width: 250px; transform: translateX(120%); transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
.toast.show { transform: translateX(0); }
.toast-icon { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; background: var(--primary); flex-shrink: 0;}
.toast.error .toast-icon { background: var(--danger); }
.toast-msg { font-size: 0.95rem; font-weight: 800; color: var(--text-main); line-height: 1.3;}

/* SWAL CUSTOM */
.swal-modal-custom { background: var(--card-bg) !important; border: 1px solid var(--card-border) !important; border-radius: 24px !important; padding: 24px !important; width: 90% !important; max-width: 400px !important; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5) !important; }
.swal-title-custom { font-size: 1.3rem !important; font-weight: 800 !important; color: var(--text-main) !important; font-family: 'Manrope', sans-serif !important; margin-bottom: 6px !important; text-align: left !important;}
.swal-desc-custom { font-size: 0.85rem !important; color: var(--text-muted) !important; font-weight: 500 !important; font-family: 'Manrope', sans-serif !important; margin-bottom: 24px !important; text-align: left !important;}
.swal2-actions { width: 100% !important; display: flex !important; gap: 12px !important; margin-top: 10px !important;}
.swal-btn-cancel, .swal-btn-confirm { flex: 1 !important; border-radius: 14px !important; padding: 16px !important; font-weight: 800 !important; border: none !important; cursor: pointer !important; font-size: 0.95rem !important; transition: transform 0.15s !important; outline: none !important; margin: 0 !important; display: flex !important; align-items: center !important; justify-content: center !important; gap: 8px !important;}
.swal-btn-cancel:active, .swal-btn-confirm:active { transform: scale(0.95) !important; }
.swal-btn-cancel { background: var(--inner-bg) !important; color: var(--text-main) !important; border: 1px solid var(--card-border) !important; }
.swal-btn-confirm.danger { background: #ef4444 !important; color: white !important;}
</style>

<div id="toast-container"></div>

<div class="apk-wrapper">

    <h1 class="main-title" data-i18n="gerar_apk_title">Gerar APK</h1>

    <div id="build-form-screen" style="display:flex; flex-direction:column; gap:24px;">
        
        <div class="apk-card">
            <h2 class="card-header-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:20px;color:var(--text-muted);"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg> <span data-i18n="config_build">Configuração de build</span></h2>
            <p class="card-desc" data-i18n="config_build_desc">Defina os parâmetros e inicie uma nova compilação.</p>
            <div style="display:flex; gap:10px; margin-top:-5px; margin-bottom: 5px;">
                <span style="background:transparent; border:1px solid var(--card-border); padding:4px 12px; border-radius:20px; font-size:0.7rem; font-weight:800; color:var(--text-muted);" data-i18n="pronto">PRONTO</span>
                <span style="background:transparent; border:1px solid var(--card-border); padding:4px 12px; border-radius:20px; font-size:0.7rem; font-weight:800; color:var(--text-muted);" data-i18n="auto_update">ATUALIZAÇÃO AUTOMÁTICA</span>
            </div>

            <div class="summary-grid">
                <div class="build-summary-box">
                    <div class="bsb-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg></div>
                    <div class="bsb-info">
                        <span class="bsb-lbl" data-i18n="base_selecionada">BASE SELECIONADA</span>
                        <span class="bsb-val" id="lbl-top-base">DTunnel Lite</span>
                    </div>
                </div>
                <div class="build-summary-box">
                    <div class="bsb-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg></div>
                    <div class="bsb-info">
                        <span class="bsb-lbl" data-i18n="versao">VERSÃO</span>
                        <span class="bsb-val" id="lbl-top-version">4.5.12 (22)</span>
                    </div>
                </div>
                <div class="build-summary-box" style="cursor:pointer;" onclick="scrollToLinks()">
                    <div class="bsb-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg></div>
                    <div class="bsb-info">
                        <span class="bsb-lbl" data-i18n="links_sessao_lbl">LINKS DESTA SESSÃO</span>
                        <span class="bsb-val"><span id="lbl-top-links-count">0</span> <span data-i18n="registros">registros</span></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="apk-card" id="session-links-card">
            <h2 class="card-header-title" data-i18n="links_sessao">Links desta sessão</h2>
            <p class="card-desc" data-i18n="links_desc">Histórico dos APKs gerados durante esta sessão.</p>
            
            <div class="session-links-header">
                <button class="sl-tab active" id="tab-0-links" data-i18n="zero_links">0 links</button>
                <button class="sl-tab" data-i18n="sessao_atual">Sessão atual</button>
            </div>
            
            <div class="empty-links" id="empty-links-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                <span data-i18n="nenhum_link">Nenhum link nesta sessão</span>
                <p data-i18n="gere_um_apk">Gere um APK para que os links apareçam aqui.</p>
            </div>

            <div id="filled-links-state" style="display:none; flex-direction:column;">
                <button class="btn-clear-history" onclick="clearAllLinks()" data-i18n="limpar_hist">Limpar histórico</button>
                <div id="history-list" style="display:flex; flex-direction:column;"></div>
            </div>
        </div>

        <div class="apk-card">
            <h2 class="card-header-title" data-i18n="param_comp">Parâmetros da compilação</h2>
            <div style="width:100%; height:1px; background:var(--card-border); margin:10px 0;"></div>
            
            <div style="display:flex; justify-content:center; margin-bottom:10px;">
                <span style="background:transparent; border:1px solid var(--card-border); padding:6px 20px; border-radius:20px; font-size:0.75rem; font-weight:800; color:var(--text-muted); text-transform:uppercase;">BUILD PROFILE</span>
            </div>
            
            <div class="form-grid">
                <div class="form-group">
                    <label class="form-label" data-i18n="lbl_base">Versão base</label>
                    <select class="form-select" id="inp-base" onchange="updateTopLabels()">
                        <option value="">Carregando bases...</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label" data-i18n="lbl_nome">Nome do APK</label>
                    <input type="text" class="form-input" id="inp-name" value="DTunnel Lite">
                </div>
                
                <div class="form-group">
                    <label class="form-label" data-i18n="lbl_pacote">Nome pacote</label>
                    <input type="text" class="form-input" id="inp-package" value="com.dtunnel.lite">
                </div>
                
                <div class="form-group">
                    <label class="form-label" data-i18n="lbl_ver_name">Nome da versão</label>
                    <input type="text" class="form-input" id="inp-ver-name" value="4.5.12" oninput="updateTopLabels()">
                </div>
                
                <div class="form-group">
                    <label class="form-label" data-i18n="lbl_ver_code">Código da versão</label>
                    <input type="text" class="form-input" id="inp-ver-code" value="22" oninput="updateTopLabels()">
                </div>

                <div class="form-group">
                    <label class="form-label" data-i18n="lbl_logo">URL da logo</label>
                    <input type="text" class="form-input" id="inp-logo" placeholder="https://exemplo.com/icon.png">
                </div>
            </div>

            <div style="margin-top: 20px;">
                <h3 style="font-size:1rem; font-weight:800; color:var(--text-main); margin:0 0 5px 0;" data-i18n="pacote_off">Pacote offline</h3>
                <p class="card-desc" style="margin-bottom:15px;" data-i18n="pacote_desc">Escolha quais dados vão embarcados no APK gerado.</p>
                
                <div class="offline-grid">
                    <label class="checkbox-item"><input type="checkbox" style="display:none;" checked><div class="custom-cb"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div><span class="cb-label" data-i18n="cb_tema">Tema</span></label>
                    <label class="checkbox-item"><input type="checkbox" style="display:none;" checked><div class="custom-cb"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div><span class="cb-label" data-i18n="cb_textos">Textos</span></label>
                    <label class="checkbox-item"><input type="checkbox" style="display:none;" checked><div class="custom-cb"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div><span class="cb-label" data-i18n="cb_cdns">CDNs</span></label>
                    <label class="checkbox-item"><input type="checkbox" style="display:none;"><div class="custom-cb"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div><span class="cb-label" data-i18n="cb_config">Configurações</span></label>
                </div>
            </div>

            <div style="display:flex; justify-content:flex-end; margin-top:10px;">
                <button class="btn-master-build" style="width:auto; padding: 14px 24px;" onclick="startBuildProcess()">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    <span data-i18n="btn_gerar">Gerar APK</span>
                </button>
            </div>
        </div>
    </div>

    <!-- TELA PROGRESSO (Ritmo e UI idênticos ao print) -->
    <div id="build-progress-screen">
        <div class="apk-card" style="padding: 24px; padding-bottom: 10px;">
            <div style="display:flex; align-items:center; gap: 16px; margin-bottom: 10px;">
                <div class="bsb-icon" style="color: var(--primary);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg></div>
                <div>
                    <h1 class="main-title" style="font-size: 1.3rem;" id="title-gerando" data-i18n="gerando">Gerando...</h1>
                    <p class="card-desc" style="margin-top:2px;" id="desc-gerando" data-i18n="gerando_desc">Acompanhe o progresso e os logs retornados pelo compilador.</p>
                </div>
            </div>
            
            <div style="display:flex; gap:10px; margin-bottom: 20px;">
                <span id="badge-pct-top" style="background:var(--primary-light); color:var(--primary); padding:4px 12px; border-radius:20px; font-size:0.75rem; font-weight:800;">0%</span>
                <span style="background:transparent; border:1px solid var(--card-border); padding:4px 12px; border-radius:20px; font-size:0.75rem; font-weight:800; color:var(--text-muted);" data-i18n="auto_update">ATUALIZAÇÃO AUTOMÁTICA</span>
            </div>

            <div class="summary-grid" style="margin-bottom: 10px;">
                <div class="prog-status-row">
                    <div class="prog-icon-pulse"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg></div>
                    <div style="flex:1;">
                        <div class="prog-info-lbl" data-i18n="status">STATUS</div>
                        <div class="prog-info-val" id="lbl-status-build" data-i18n="em_processo">Em processamento</div>
                    </div>
                </div>

                <div class="prog-status-row">
                    <div class="prog-icon-pulse"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg></div>
                    <div style="flex:1;">
                        <div class="prog-info-lbl" data-i18n="progresso">PROGRESSO</div>
                        <div class="prog-info-val" id="lbl-pct-build">0%</div>
                    </div>
                </div>

                <div class="prog-status-row">
                    <div class="prog-icon-pulse"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg></div>
                    <div style="flex:1;">
                        <div class="prog-info-lbl" data-i18n="eventos">EVENTOS</div>
                        <div class="prog-info-val"><span id="lbl-logs-count">0</span> <span data-i18n="registros">registros</span></div>
                    </div>
                </div>
            </div>

            <div class="prog-bar-container">
                <div class="prog-bar-header">
                    <span data-i18n="progresso_comp">Progresso da compilação</span>
                    <span id="lbl-bar-pct" style="background:var(--inner-bg); padding:4px 10px; border-radius:10px; font-size:0.75rem; border:1px solid var(--card-border);">0%</span>
                </div>
                <div class="prog-bar-bg">
                    <div class="prog-bar-fill" id="bar-fill-build"></div>
                </div>
            </div>
            
            <div class="terminal-card">
                <div class="terminal-header">
                    <div class="th-title-wrap">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:20px;" class="th-icon"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
                        <div>
                            <div class="th-title" data-i18n="logs_comp">Logs da compilação</div>
                            <div class="th-subtitle" data-i18n="saida_tempo_real">Saída em tempo real do build</div>
                        </div>
                    </div>
                    <span class="th-live">LIVE</span>
                </div>
                <div class="terminal-body" id="terminal-body"></div>
            </div>
        </div>
    </div>

    <!-- TELA SUCESSO (Botões Responsivos e Link com Rolagem Perfeita) -->
    <div id="build-success-screen">
        
        <div class="apk-card">
            <h2 class="card-header-title" data-i18n="links_sessao">Links desta sessão</h2>
            <p class="card-desc" data-i18n="links_desc">Histórico dos APKs gerados durante esta sessão.</p>
            
            <div class="session-links-header">
                <button class="sl-tab active" id="tab-0-links-success">1 links</button>
                <button class="sl-tab" data-i18n="sessao_atual">Sessão atual</button>
            </div>
            
            <div id="filled-links-state-success" style="display:flex; flex-direction:column; margin-top:10px;">
                <button class="btn-clear-history" onclick="clearAllLinks()" data-i18n="limpar_hist">Limpar histórico</button>
                <div id="history-list-success" style="display:flex; flex-direction:column;"></div>
            </div>
        </div>

        <div class="apk-pronto-card">
            <h2 class="ap-header" data-i18n="apk_pronto">APK pronto</h2>
            <p class="ap-desc" data-i18n="apk_pronto_desc">A compilação terminou e o arquivo já esta disponível para download.</p>

            <div class="ap-status-box">
                <div class="ap-status-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg></div>
                <div style="flex:1;">
                    <div style="font-size:0.7rem; font-weight:800; color:var(--text-subtle); text-transform:uppercase;" data-i18n="base">BASE</div>
                    <div style="font-size:0.95rem; font-weight:800; color:var(--text-main);" id="ap-base-name">base.mod.pro</div>
                </div>
            </div>

            <div class="ap-status-box">
                <div class="ap-status-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg></div>
                <div style="flex:1;">
                    <div style="font-size:0.7rem; font-weight:800; color:var(--text-subtle); text-transform:uppercase;" data-i18n="versao">VERSÃO</div>
                    <div style="font-size:0.95rem; font-weight:800; color:var(--text-main);" id="ap-ver-name">4.5.12</div>
                </div>
            </div>

            <div class="ap-status-box">
                <div class="ap-status-icon check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></div>
                <div style="flex:1;">
                    <div style="font-size:0.7rem; font-weight:800; color:var(--text-subtle); text-transform:uppercase;" data-i18n="status">STATUS</div>
                    <div style="font-size:0.95rem; font-weight:800; color:var(--text-main);" data-i18n="concluido">Concluído</div>
                </div>
            </div>

            <div class="final-link-container">
                <span class="flc-label" data-i18n="link_final">LINK FINAL DE DOWNLOAD</span>
                <div class="flc-input" id="final-apk-link" style="overflow-x:auto; -webkit-overflow-scrolling: touch; padding-bottom: 2px;">https://...</div>
            </div>

            <div class="ap-buttons">
                <button class="btn-ap" onclick="copyFinalLink()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> <span data-i18n="copiar_link">Copiar link</span></button>
                <button class="btn-ap" onclick="downloadFinalApk()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> <span data-i18n="baixar_apk">Baixar APK</span></button>
                <button class="btn-ap" onclick="resetToForm()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg> <span data-i18n="gerar_outro">Gerar outro</span></button>
            </div>
        </div>

    </div>

</div>

<?php
$pageContent = ob_get_clean();

$extraJs = <<<JS
<script>
// ======================================================================
// INTEGRAÇÃO i18n GLOBAL (Trabalha em conjunto com o header.php)
// ======================================================================
const localTranslations = {
    'pt': {
        'gerar_apk_title': 'Gerar APK', 'config_build': 'Configuração de build', 'config_build_desc': 'Defina os parâmetros e inicie uma nova compilação.',
        'pronto': 'PRONTO', 'auto_update': 'ATUALIZAÇÃO AUTOMÁTICA', 'base_selecionada': 'BASE SELECIONADA', 'versao': 'VERSÃO',
        'links_sessao_lbl': 'LINKS DESTA SESSÃO', 'registros': 'registros', 'links_sessao': 'Links desta sessão', 'links_desc': 'Histórico dos APKs gerados durante esta sessão.',
        'zero_links': '0 links', 'sessao_atual': 'Sessão atual', 'nenhum_link': 'Nenhum link nesta sessão', 'gere_um_apk': 'Gere um APK para que os links apareçam aqui.',
        'param_comp': 'Parâmetros da compilação', 'lbl_base': 'Versão base', 'lbl_nome': 'Nome do APK', 'lbl_pacote': 'Nome pacote',
        'lbl_ver_name': 'Nome da versão', 'lbl_ver_code': 'Código da versão', 'lbl_logo': 'URL da logo',
        'pacote_off': 'Pacote offline', 'pacote_desc': 'Escolha quais dados vão embarcados no APK gerado.', 
        'cb_tema': 'Tema', 'cb_textos': 'Textos', 'cb_cdns': 'CDNs', 'cb_config': 'Configurações', 'btn_gerar': 'Gerar APK',
        'gerando': 'Gerando...', 'gerando_desc': 'Acompanhe o progresso e os logs retornados pelo compilador.', 'compilando': 'Compilação em andamento', 'compilando_desc': 'Build ativo com 89% concluído e logs em tempo real.',
        'status': 'STATUS', 'em_processo': 'Em processamento', 'progresso': 'PROGRESSO', 'eventos': 'EVENTOS',
        'progresso_comp': 'Progresso da compilação', 'logs_comp': 'Logs da compilação', 'saida_tempo_real': 'Saída em tempo real do build',
        'limpar_hist': 'Limpar histórico', 'apk_pronto': 'APK pronto', 'apk_pronto_desc': 'A compilação terminou e o arquivo já esta disponível para download.',
        'base': 'BASE', 'concluido': 'Concluído', 'link_final': 'LINK FINAL DE DOWNLOAD',
        'copiar_link': 'Copiar link', 'baixar_apk': 'Baixar APK', 'gerar_outro': 'Gerar outro',
        'toast_copied': 'Link copiado!', 'toast_deleted': 'APK removido do servidor.'
    },
    'en': {
        'gerar_apk_title': 'Generate APK', 'config_build': 'Build Configuration', 'config_build_desc': 'Set parameters and start a new build.',
        'pronto': 'READY', 'auto_update': 'AUTO UPDATE', 'base_selecionada': 'SELECTED BASE', 'versao': 'VERSION',
        'links_sessao_lbl': 'LINKS THIS SESSION', 'registros': 'records', 'links_sessao': 'Links of this session', 'links_desc': 'History of APKs generated during this session.',
        'zero_links': '0 links', 'sessao_atual': 'Current session', 'nenhum_link': 'No link in this session', 'gere_um_apk': 'Generate an APK for links to appear here.',
        'param_comp': 'Build Parameters', 'lbl_base': 'Base Version', 'lbl_nome': 'APK Name', 'lbl_pacote': 'Package Name',
        'lbl_ver_name': 'Version Name', 'lbl_ver_code': 'Version Code', 'lbl_logo': 'Logo URL',
        'pacote_off': 'Offline Package', 'pacote_desc': 'Choose which data goes embedded in generated APK.', 
        'cb_tema': 'Theme', 'cb_textos': 'Texts', 'cb_cdns': 'CDNs', 'cb_config': 'Settings', 'btn_gerar': 'Generate APK',
        'gerando': 'Generating...', 'gerando_desc': 'Track progress and logs returned by the compiler.', 'compilando': 'Compilation in progress', 'compilando_desc': 'Active build 89% complete with real-time logs.',
        'status': 'STATUS', 'em_processo': 'Processing', 'progresso': 'PROGRESS', 'eventos': 'EVENTS',
        'progresso_comp': 'Build Progress', 'logs_comp': 'Compilation Logs', 'saida_tempo_real': 'Real-time build output',
        'limpar_hist': 'Clear history', 'apk_pronto': 'APK ready', 'apk_pronto_desc': 'Compilation has finished and the file is ready for download.',
        'base': 'BASE', 'concluido': 'Completed', 'link_final': 'FINAL DOWNLOAD LINK',
        'copiar_link': 'Copy link', 'baixar_apk': 'Download APK', 'gerar_outro': 'Generate another',
        'toast_copied': 'Link copied!', 'toast_deleted': 'APK removed from server.'
    },
    'es': {
        'gerar_apk_title': 'Generar APK', 'config_build': 'Configuración de build', 'config_build_desc': 'Defina parámetros e inicie una nueva compilación.',
        'pronto': 'LISTO', 'auto_update': 'ACTUALIZACIÓN AUTOMÁTICA', 'base_selecionada': 'BASE SELECCIONADA', 'versao': 'VERSIÓN',
        'links_sessao_lbl': 'ENLACES DE ESTA SESIÓN', 'registros': 'registros', 'links_sessao': 'Enlaces de esta sesión', 'links_desc': 'Historial de APKs generados en esta sesión.',
        'zero_links': '0 enlaces', 'sessao_atual': 'Sesión actual', 'nenhum_link': 'Ningún enlace en esta sesión', 'gere_um_apk': 'Genere un APK para que los enlaces aparezcan aquí.',
        'param_comp': 'Parámetros de compilación', 'lbl_base': 'Versión base', 'lbl_nome': 'Nombre del APK', 'lbl_pacote': 'Nombre paquete',
        'lbl_ver_name': 'Nombre de versión', 'lbl_ver_code': 'Código de versión', 'lbl_logo': 'URL del logo',
        'pacote_off': 'Paquete offline', 'pacote_desc': 'Elija qué datos van incrustados en el APK generado.', 
        'cb_tema': 'Tema', 'cb_textos': 'Textos', 'cb_cdns': 'CDNs', 'cb_config': 'Ajustes', 'btn_gerar': 'Generar APK',
        'gerando': 'Generando...', 'gerando_desc': 'Siga el progreso y los registros devueltos por el compilador.', 'compilando': 'Compilación en progreso', 'compilando_desc': 'Build activo al 89% con registros en tiempo real.',
        'status': 'ESTADO', 'em_processo': 'En proceso', 'progresso': 'PROGRESO', 'eventos': 'EVENTOS',
        'progresso_comp': 'Progreso de compilación', 'logs_comp': 'Registros de compilación', 'saida_tempo_real': 'Salida en tiempo real del build',
        'limpar_hist': 'Limpiar historial', 'apk_pronto': 'APK listo', 'apk_pronto_desc': 'La compilación ha terminado y el archivo está listo para su descarga.',
        'base': 'BASE', 'concluido': 'Completado', 'link_final': 'ENLACE FINAL DE DESCARGA',
        'copiar_link': 'Copiar enlace', 'baixar_apk': 'Descargar APK', 'gerar_outro': 'Generar otro',
        'toast_copied': '¡Enlace copiado!', 'toast_deleted': 'APK eliminado del servidor.'
    }
};

// Injeta as traduções locais no motor global do header
if (typeof window.globalTranslations !== 'undefined') {
    Object.keys(localTranslations).forEach(lang => {
        if (!window.globalTranslations[lang]) window.globalTranslations[lang] = {};
        Object.assign(window.globalTranslations[lang], localTranslations[lang]);
    });
}

function getMsg(key) { 
    const lang = localStorage.getItem('app_language') || 'pt'; 
    return (window.globalTranslations && window.globalTranslations[lang] && window.globalTranslations[lang][key]) 
        ? window.globalTranslations[lang][key] 
        : (localTranslations['pt'][key] || key); 
}

function showToastRaw(text, type = 'success') {
    const container = document.getElementById('toast-container'); const t = document.createElement('div'); t.className = `toast \${type}`;
    let iconSvg = '<polyline points="20 6 9 17 4 12"/>';
    if (type === 'error') iconSvg = '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>';
    t.innerHTML = `<div class="toast-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" style="width:14px;">\${iconSvg}</svg></div><div class="toast-msg">\${text}</div>`;
    container.appendChild(t); requestAnimationFrame(()=>t.classList.add('show'));
    setTimeout(()=>{t.classList.remove('show'); setTimeout(()=>t.remove(), 300)}, 2500);
}

// VARIÁVEIS GLOBAIS
let generatedLinks = [];
let currentGeneratedFile = '';
let currentRealUrl = '';
let currentFinalUrlToCopy = '';

// INICIALIZAÇÃO E APLICAÇÃO DE IDIOMA
document.addEventListener('DOMContentLoaded', () => { 
    // Como injetamos no globalTranslations, basta chamar a função do header
    const savedLang = localStorage.getItem('app_language') || 'pt';
    if(typeof window.selectAppLang === 'function') {
        window.selectAppLang(savedLang); 
    }
    loadBases();
});

function loadBases() {
    fetch('?action=list_bases', {method:'POST'}).then(r=>r.json()).then(res => {
        const sel = document.getElementById('inp-base');
        sel.innerHTML = '';
        if(res.success && res.bases.length > 0) {
            res.bases.forEach(b => { 
                const selected = b.toLowerCase().includes('lite') ? 'selected' : '';
                sel.innerHTML += `<option value="\${b}" \${selected}>\${b}</option>`; 
            });
        } else {
            sel.innerHTML = '<option value="">Nenhuma base</option>';
        }
        updateTopLabels();
    });
}

function updateTopLabels() {
    let base = document.getElementById('inp-base').value || 'Nenhuma';
    base = base.replace('.apk', ''); // Limpa extensao
    const vName = document.getElementById('inp-ver-name').value || '1.0';
    const vCode = document.getElementById('inp-ver-code').value || '1';
    document.getElementById('lbl-top-base').innerText = base;
    document.getElementById('lbl-top-version').innerText = `\${vName} (\${vCode})`;
}

function scrollToLinks() {
    document.getElementById('session-links-card').scrollIntoView({behavior: 'smooth'});
}

// ======================================================================
// GERAÇÃO DOS 100 LOGS COM INFORMAÇÕES EXATAS DO APKTOOL (Idêntico ao print)
// ======================================================================
const terminal = document.getElementById('terminal-body');

// Base de frases para montar os 100 logs perfeitamente realistas
const logPhrases = [
    "Loading resource table...", "Decoding file-resources...", "Loading resource table from file: /root/.local/share/apktool/framework/1.apk",
    "Decoding values */* XMLs...", "Decoding AndroidManifest.xml with resources...", "Regular manifest package...",
    "Copying raw classes.dex file...", "Copying raw classes2.dex file...", "Copying assets and libs...",
    "Building resources...", "Copying libs... (/lib)", "Copying libs... (/kotlin)", "Building apk file...",
    "Copying unknown files/dir...", "Optimizing generated apk...", "Injecting DTunnelMod JSON..."
];

// Pré-gera os 100 logs
let final100Logs = [];
final100Logs.push("I: Using Apktool 2.9.3 on base.apk");
for(let i=2; i<=99; i++) {
    // Para dar o ar super profissional, alguns logs serão da compactação META-INF
    if(i > 80 && i < 98) {
        let r1 = Math.floor(Math.random() * 9000000) + 1000000;
        let p = Math.random() > 0.5 ? "ka.o0" : "xb.a";
        final100Logs.push(`\${r1} META-INF/services/\${p} (OK - compressed)`);
    } else {
        let phrase = logPhrases[Math.floor(Math.random() * logPhrases.length)];
        if(phrase.includes("Copying")) phrase += " tmp/obj_" + Math.random().toString(36).substr(2, 6);
        final100Logs.push("I: " + phrase);
    }
}
final100Logs.push("I: Uploading generated APK.");

function addTerminalLog(index, text) {
    document.getElementById('lbl-logs-count').innerText = index;
    const numStr = index < 10 ? '0' + index : index;
    
    // HTML ESPECÍFICO RECONSTRUÍDO IGUAL À FOTO ENVIADA
    const html = `
    <div class="log-entry">
        <div class="log-icon-left">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>
            </svg>
        </div>
        <div class="log-content">
            <div class="log-top-row">
                <span class="log-num">#\${numStr}</span>
                <span class="log-badge-label">LOG</span>
            </div>
            <div class="log-text">\${text}</div>
        </div>
    </div>`;
    
    terminal.innerHTML += html;
    terminal.scrollTop = terminal.scrollHeight;
}

// Ritmo de Compilação Realista - BEM MAIS LENTO
function startBuildProcess() {
    const base = document.getElementById('inp-base').value;
    if(!base) { showToastRaw('Selecione uma base primeiro!', 'error'); return; }

    document.getElementById('build-form-screen').style.display = 'none';
    document.getElementById('build-progress-screen').style.display = 'flex';
    
    terminal.innerHTML = '';
    updateProgress(0);
    document.getElementById('lbl-status-build').innerText = getMsg('em_processo');
    document.getElementById('title-gerando').innerText = getMsg('gerando');
    document.getElementById('desc-gerando').innerText = getMsg('gerando_desc');

    let currentPct = 0;

    function simulateProgress() {
        if(currentPct >= 100) {
            document.getElementById('lbl-status-build').innerText = getMsg('concluido');
            executeRealBackendBuild();
            return;
        }

        // Avança na maioria das vezes de 1 em 1% para ser bem suave e realista
        let increment = Math.random() > 0.8 ? 2 : 1;
        currentPct += increment;
        if(currentPct > 100) currentPct = 100;

        updateProgress(currentPct);
        
        // Sincroniza o LOG com a porcentagem
        addTerminalLog(currentPct, final100Logs[currentPct - 1]);

        // Textos especiais na interface dependendo da %
        if(currentPct === 89) {
            document.getElementById('title-gerando').innerText = getMsg('compilando');
            document.getElementById('desc-gerando').innerText = getMsg('compilando_desc');
        }

        // DELAYS AUMENTADOS - RITMO PROFISSIONAL DE COMPILADOR
        let delay = Math.random() * 250 + 150; // Delay normal entre 150ms e 400ms por log
        
        if (currentPct === 48 || currentPct === 49) {
            delay = 2500; // Super pausa nos recursos (48%)
        } else if (currentPct === 61 || currentPct === 62) {
            delay = 1800; // Outra pausa processando classes dex
        } else if (currentPct === 89 || currentPct === 90) {
            delay = 3500; // A maior pausa (otimizando e assinando APK - 89%)
        }

        setTimeout(simulateProgress, delay);
    }

    // Inicia a simulação
    setTimeout(simulateProgress, 500);
}

function updateProgress(val) {
    document.getElementById('lbl-pct-build').innerText = val + '%';
    document.getElementById('lbl-bar-pct').innerText = val + '%';
    document.getElementById('badge-pct-top').innerText = val + '%';
    document.getElementById('bar-fill-build').style.width = val + '%';
}

function executeRealBackendBuild() {
    const payload = {
        base: document.getElementById('inp-base').value,
        name: document.getElementById('inp-name').value,
        versionName: document.getElementById('inp-ver-name').value
    };

    fetch('?action=build_apk', { method: 'POST', body: JSON.stringify(payload) })
    .then(r=>r.json()).then(res => {
        if(res.success) {
            setTimeout(() => {
                document.getElementById('build-progress-screen').style.display = 'none';
                document.getElementById('build-success-screen').style.display = 'flex';
                
                // Preenche Card Verde
                document.getElementById('final-apk-link').innerText = res.download_url;
                currentFinalUrlToCopy = res.download_url; // guarda o url para copiar facil

                let baseClean = document.getElementById('inp-base').value.replace('.apk','');
                document.getElementById('ap-base-name').innerText = baseClean;
                document.getElementById('ap-ver-name').innerText = payload.versionName;
                
                currentGeneratedFile = res.filename;
                currentRealUrl = res.real_url;
                
                // Add ao historico
                generatedLinks.unshift({
                    name: payload.name, 
                    displayBase: baseClean.toUpperCase(),
                    verName: payload.versionName,
                    verCode: document.getElementById('inp-ver-code').value,
                    date: res.date,
                    link: res.download_url, 
                    realUrl: res.real_url,
                    file: res.filename
                });
                
                renderGeneratedLinks();
                
            }, 800);
        } else {
            Swal.fire('Erro na Compilação', res.error, 'error');
            resetToForm();
        }
    }).catch(e => {
        Swal.fire('Erro Fatal', 'Servidor não respondeu.', 'error');
        resetToForm();
    });
}

function resetToForm() {
    document.getElementById('build-success-screen').style.display = 'none';
    document.getElementById('build-progress-screen').style.display = 'none';
    document.getElementById('build-form-screen').style.display = 'flex';
}

// AÇÕES DOS BOTÕES FINAIS
function copyFinalLink() { copyTextToClipboard(currentFinalUrlToCopy); }
function copySpecificLink(link) { copyTextToClipboard(link); }

function copyTextToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(() => { showToastRaw(getMsg('toast_copied'), 'success'); });
    } else {
        let tempInput = document.createElement("input");
        tempInput.value = text;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand("copy");
        document.body.removeChild(tempInput);
        showToastRaw(getMsg('toast_copied'), 'success');
    }
}

// Download Funcional via JS
function triggerDownload(url, filename) {
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = filename || 'dtunnel-mod.apk';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

function downloadFinalApk() { triggerDownload(currentRealUrl, currentGeneratedFile); }
function downloadSpecific(url, file) { triggerDownload(url, file); }

function deleteSpecific(filename) {
    const isDark = document.documentElement.classList.contains('dark') || document.body.classList.contains('dark');
    Swal.fire({
        html: `<div class="swal-header-custom" style="display:flex; align-items:center; gap:14px; margin-bottom:16px;"><div style="width:48px;height:48px;border-radius:14px;background:rgba(239,68,68,0.1);color:#ef4444;display:flex;align-items:center;justify-content:center;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:24px;"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></div><h2 class="swal-title-custom" style="text-align:left; margin:0;" data-i18n="excluir_apk">Excluir APK</h2></div><p class="swal-desc-custom" style="text-align:left;" data-i18n="excluir_desc">Deseja realmente apagar o arquivo do servidor? O link deixará de funcionar.</p>`,
        customClass: { popup: 'swal-modal-custom', confirmButton: 'swal-btn-confirm danger', cancelButton: 'swal-btn-cancel', actions: 'swal2-actions' },
        background: isDark ? '#1a1a1e' : '#ffffff', color: isDark ? '#ffffff' : '#111827', backdrop: `rgba(0,0,0,0.85)`, buttonsStyling: false, showCancelButton: true, confirmButtonText: getMsg('delete'), cancelButtonText: getMsg('cancel')
    }).then((res) => {
        if(res.isConfirmed) {
            fetch('?action=delete_apk', { method:'POST', body: JSON.stringify({filename: filename}) })
            .then(r=>r.json()).then(resp => {
                showToastRaw(getMsg('toast_deleted'), 'error');
                generatedLinks = generatedLinks.filter(x => x.file !== filename);
                renderGeneratedLinks();
                if(currentGeneratedFile === filename && document.getElementById('build-success-screen').style.display === 'flex') {
                    resetToForm();
                }
            });
        }
    });
}

function clearAllLinks() {
    generatedLinks = [];
    renderGeneratedLinks();
}

// RENDERIZAÇÃO DO CARD DO HISTÓRICO 
function renderGeneratedLinks() {
    const len = generatedLinks.length;
    
    document.getElementById('lbl-top-links-count').innerText = len;
    document.getElementById('tab-0-links').innerText = len + ' links';
    document.getElementById('tab-0-links-success').innerText = len + ' links';
    
    const emptyForm = document.getElementById('empty-links-state');
    const filledForm = document.getElementById('filled-links-state');
    const listForm = document.getElementById('history-list');
    
    const listSuccess = document.getElementById('history-list-success');
    const filledSuccess = document.getElementById('filled-links-state-success');
    
    if(len === 0) {
        emptyForm.style.display = 'flex'; filledForm.style.display = 'none';
        if(filledSuccess) filledSuccess.style.display = 'none';
    } else {
        emptyForm.style.display = 'none'; filledForm.style.display = 'flex';
        if(filledSuccess) filledSuccess.style.display = 'flex';
        
        let htmlStr = '';
        generatedLinks.forEach(item => {
            htmlStr += `
                <div class="history-item">
                    <div class="hi-top">
                        <div class="hi-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg></div>
                        <div class="hi-info">
                            <span class="hi-title">\${item.name}</span>
                            <span class="hi-sub">\${item.displayBase} • v\${item.verName} (\${item.verCode})<br>\${item.date}</span>
                        </div>
                    </div>
                    
                    <div class="hi-link-wrapper">
                        <div class="hi-link-text">\${item.link}</div>
                    </div>
                    
                    <div class="hi-actions">
                        <button class="btn-hi" onclick="copySpecificLink('\${item.link}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>
                        <button class="btn-hi" onclick="downloadSpecific('\${item.realUrl}', '\${item.file}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></button>
                        <button class="btn-hi trash" onclick="deleteSpecific('\${item.file}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>
                    </div>
                </div>
            `;
        });
        
        listForm.innerHTML = htmlStr;
        if(listSuccess) listSuccess.innerHTML = htmlStr;
    }
}
</script>
JS;

$layoutFile = __DIR__ . '/../includes/layout.php';
if (file_exists($layoutFile)) { include $layoutFile; } 
else { echo $pageContent . $extraJs; }
?>